local isOn = false

Citizen.CreateThread(function()
	while true do
		if IsControlJustReleased(0, 29) then --The key/button can be easily changed by simply changing the second number https://docs.fivem.net/docs/game-references/controls/
			if IsPedInAnyVehicle(PlayerPedId()) then
				local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
				if isOn then
					-- aus
					local maxSpeed = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fInitialDriveMaxFlatVel")
					SetEntityMaxSpeed(vehicle, maxSpeed)
					ShowNotification('Dein Limiter wurde ~r~ausgeschaltet')
					isOn = false
				else
					-- an
					local currSpeed = GetEntitySpeed(vehicle)
					local currKMH = currSpeed * 3.6
					SetEntityMaxSpeed(vehicle, currSpeed)
					ShowNotification('Dein Limiter wurde auf ~g~' .. math.floor(currKMH) .. ' KM/H ~s~ eingestellt')
					isOn = true
				end
			end
		end
		Citizen.Wait(1)
	end
end)

function ShowNotification(text)
	SetNotificationTextEntry('STRING')
	AddTextComponentString(text)
	DrawNotification(false, true)
end
